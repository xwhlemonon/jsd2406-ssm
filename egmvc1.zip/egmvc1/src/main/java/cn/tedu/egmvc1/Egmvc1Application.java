package cn.tedu.egmvc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Egmvc1Application {

    public static void main(String[] args) {
        SpringApplication.run(Egmvc1Application.class, args);
    }

}
