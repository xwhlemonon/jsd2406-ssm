package cn.tedu.egmvc1.pojo.dto;

import lombok.Data;

@Data
public class UserUpdateDTO1 {
    private String id;
    private String name;
    private Double salary;
    private String job;
}
