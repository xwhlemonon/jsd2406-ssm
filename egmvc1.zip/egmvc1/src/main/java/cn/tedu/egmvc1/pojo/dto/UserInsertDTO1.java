package cn.tedu.egmvc1.pojo.dto;

import lombok.Data;

@Data
public class UserInsertDTO1 {
    private String name;
    private Double salary;
    private String job;
}
