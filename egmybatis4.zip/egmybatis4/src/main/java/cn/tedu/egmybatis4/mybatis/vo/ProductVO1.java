package cn.tedu.egmybatis4.mybatis.vo;

import lombok.Data;

@Data
public class ProductVO1 {
    private String title;
    private Integer stock;
}
