package cn.tedu.egmybatis4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Egmybatis4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
