package cn.tedu.egmybatis6.pojo.entity;

import lombok.Data;

@Data
public class Customers {
    private String custId;
    private String custTel;
    private String custName;
    private String city;
}
