package cn.tedu.egmybatis6.pojo.vo;

import lombok.Data;

@Data
public class CustomersVO2 {
    private String custName;
    private String city;
}
