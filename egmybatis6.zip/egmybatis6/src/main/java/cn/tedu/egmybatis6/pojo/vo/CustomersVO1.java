package cn.tedu.egmybatis6.pojo.vo;

import lombok.Data;

@Data
public class CustomersVO1 {
    private String custName;
    private String custTel;
}
