package cn.tedu.egmybatis6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Egmybatis6Application {

    public static void main(String[] args) {
        SpringApplication.run(Egmybatis6Application.class, args);
    }

}
