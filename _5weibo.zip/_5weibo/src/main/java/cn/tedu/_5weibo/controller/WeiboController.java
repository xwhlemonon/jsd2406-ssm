package cn.tedu._5weibo.controller;

import cn.tedu._5weibo.mapper.UserMapper;
import cn.tedu._5weibo.mapper.WeiboMapper;
import cn.tedu._5weibo.pojo.vo.UserSelectUserVO;
import cn.tedu._5weibo.pojo.vo.WeiboInsertVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/v1/weibo/")
public class WeiboController {
    private WeiboMapper mapper;
    private UserMapper userMapper;

    @Autowired
    public void setMapper(WeiboMapper mapper) {
        this.mapper = mapper;
    }

    @Autowired
    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @PostMapping("insert")
    public String insertWeibo(String content, HttpSession session) {
        String user = (String) session.getAttribute("user");
        if (user == null) {
            return "用户未登录，请登录后再尝试";
        } else if (content == null || content.trim().isEmpty()) {
            return "内容不能为空";
        } else {
            List<UserSelectUserVO> users = userMapper.selectNumByUsername(user);
            WeiboInsertVO vo = new WeiboInsertVO();
            vo.setContent(content);
            vo.setCreated(new Date());
            vo.setUserId(users.get(0).getId());
            mapper.insertWeibo(vo);
            return "发布成功";
        }
    }

}
