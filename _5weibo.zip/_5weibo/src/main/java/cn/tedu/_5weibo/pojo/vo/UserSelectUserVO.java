package cn.tedu._5weibo.pojo.vo;

import lombok.Data;

@Data
public class UserSelectUserVO {
    private Long id;
    private String username;
    private String password;
}
