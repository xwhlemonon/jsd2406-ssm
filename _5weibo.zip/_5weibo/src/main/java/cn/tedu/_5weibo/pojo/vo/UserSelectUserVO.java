package cn.tedu._5weibo.pojo.vo;

import lombok.Data;

@Data
public class UserSelectUserVO {
    private String username;
    private String password;
}
