package cn.tedu._5weibo.pojo.dto;

import lombok.Data;

@Data
public class UserRegDTO {
    private String username;
    private String password;
    private String nickname;
}
