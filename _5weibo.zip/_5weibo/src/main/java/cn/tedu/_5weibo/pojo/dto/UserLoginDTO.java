package cn.tedu._5weibo.pojo.dto;

import lombok.Data;

@Data
public class UserLoginDTO {
    private String username;
    private String password;
}
