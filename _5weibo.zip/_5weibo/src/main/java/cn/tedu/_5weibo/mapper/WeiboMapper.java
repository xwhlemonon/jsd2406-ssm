package cn.tedu._5weibo.mapper;

import cn.tedu._5weibo.pojo.vo.WeiboInsertVO;

public interface WeiboMapper {
    void insertWeibo(WeiboInsertVO vo);
}
