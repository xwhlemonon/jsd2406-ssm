package cn.tedu._5weibo.mapper;

public interface WeiboMapper {
}
